import os
import subprocess
import threading
from pathlib import Path
import telebot

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("BOT_TOKEN is not set.")

bot = telebot.TeleBot(TOKEN)
PROJECT_DIR = Path(__file__).resolve().parent
JAVA_PATH = PROJECT_DIR / "app/src/main/java/com/darktunnel/app/MainActivity.java"
APK_PATH = PROJECT_DIR / "app/build/outputs/apk/debug/app-debug.apk"
LOCK = threading.Lock()

@bot.message_handler(commands=["start", "help"])
def start(message):
    bot.reply_to(message, "Send your MainActivity.java file.")

@bot.message_handler(content_types=["document"])
def document(message):
    name = message.document.file_name or ""
    if not (name.endswith(".java") or name.endswith(".txt")):
        bot.reply_to(message, "Please send a .java or .txt file.")
        return
    if not LOCK.acquire(False):
        bot.reply_to(message, "A build is already running. Please wait.")
        return
    threading.Thread(target=build, args=(message.chat.id, message.document.file_id), daemon=True).start()

def build(chat_id, file_id):
    try:
        bot.send_message(chat_id, "Building APK...")
        info = bot.get_file(file_id)
        data = bot.download_file(info.file_path)
        JAVA_PATH.parent.mkdir(parents=True, exist_ok=True)
        JAVA_PATH.write_bytes(data)

        result = subprocess.run(
            ["gradle", "assembleDebug", "--no-daemon"],
            cwd=PROJECT_DIR, capture_output=True, text=True, timeout=600
        )
        if result.returncode != 0:
            bot.send_message(chat_id, "Build failed:\n" + (result.stderr or result.stdout)[-2000:])
            return
        if APK_PATH.exists():
            with APK_PATH.open("rb") as apk:
                bot.send_document(chat_id, apk, caption="APK is ready.")
        else:
            bot.send_message(chat_id, "Build finished but APK was not found.")
    except Exception as e:
        bot.send_message(chat_id, f"Error: {e}")
    finally:
        LOCK.release()

if __name__ == "__main__":
    bot.infinity_polling(skip_pending=True)
